#!/bin/sh
. /lib/functions.sh

nvram set ssh_en=1
nvram set uart_en=1
nvram set telnet_en=1
nvram set boot_wait=on
nvram set bootcmd=bootipq
nvram set ipaddr=192.168.1.1
nvram set serverip=192.168.1.10
nvram commit

echo "Upgrading env... done"

mibib=/dev/mtd$(find_mtd_index "0:MIBIB")
uboot=/dev/mtd$(find_mtd_index "0:APPSBL")

[ -n "$mibib" ] || mibib=/dev/mtd2
[ -n "$uboot" ] || uboot=/dev/mtd18

mtd write /tmp/xiaomi-be7000-mibib.bin $mibib
if [ `echo $?` == "0" ]; then
	echo "Flashing Mibib... done"
else
	echo "Unlock Mibib failed"
fi

mtd write /tmp/xiaomi-be7000-uboot.bin $uboot
if [ `echo $?` == "0" ]; then
	echo "Flashing MiTEE... done"
else
	echo "Unlock MiTEE failed"
fi

echo "System Reboot Required"
exit 0
